#include "Header.h"

int main_1() {
    allegro_init();
    install_keyboard();
    install_mouse();
    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0))!=0)
    {
        allegro_message("pb mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);
    }


    // Création du double buffer
    BITMAP *page= create_bitmap(SCREEN_W, SCREEN_H);

    // Chargement de l'image depuis un fichier
    BITMAP *image= load_bitmap("images/surf.bmp", NULL);

    // Vérification du chargement de l'image
    if (!image) {
        allegro_message("pb chargement image");
        return 1;
    }

    // Boucle principale
    while (!key[KEY_ESC]) {
        // Effacer le buffer
        clear_bitmap(page);

        // Calculer la position de la zone visible en fonction de la souris
        int x_offset = mouse_x - SCREEN_W / 2;
        int y_offset = mouse_y - SCREEN_H / 2;

        // Afficher seulement la partie de l'image visible
        blit(image, page, x_offset, y_offset, 0, 0, SCREEN_W, SCREEN_H);

        // Afficher le contenu du buffer sur l'écran
        blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
        rest(10);
    }
    //libere memoire
    destroy_bitmap(page);
    destroy_bitmap(image);
}