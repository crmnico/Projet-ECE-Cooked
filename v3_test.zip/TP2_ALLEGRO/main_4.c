#include "Header.h"

BITMAP *page;
BITMAP *image;
BITMAP *contour_bitmap;

void detect_contours() {
    int x, y;

    // Parcourir chaque pixel de l'image
    for (y = 1; y < image->h - 1; y++) {
        for (x = 1; x < image->w - 1; x++) {
            // Récupérer la couleur des pixels voisins
            int color = getpixel(image, x, y);
            int color_left = getpixel(image, x - 1, y);
            int color_right = getpixel(image, x + 1, y);
            int color_up = getpixel(image, x, y - 1);
            int color_down = getpixel(image, x, y + 1);

            // Comparer la couleur du pixel avec celle de ses voisins
            if (color != color_left || color != color_right || color != color_up || color != color_down) {
                // Le pixel est sur un contour, dessiner un pixel blanc sur le bitmap des contours
                putpixel(contour_bitmap, x, y, makecol(255, 255, 255));
            }
        }
    }
}


int main_4() {
    // Initialisation Allegro
    allegro_init();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0))!=0)
    {
        allegro_message("pb mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    // Création du double buffer
    page = create_bitmap(SCREEN_W, SCREEN_H);

    // Chargez votre image depuis un fichier
    image = load_bitmap("images/surf.bmp", NULL);

    // Vérification du chargement de l'image
    if (!image) {
        allegro_message("Impossible de charger l'image !");
        return 1;
    }

    // Créer une bitmap pour stocker les contours
    contour_bitmap = create_bitmap(image->w, image->h);

    // Détecter les contours dans l'image
    detect_contours();

    // Boucle principale
    while (!key[KEY_ESC]) {
        // Effacer le buffer
        clear_bitmap(page);

        // Afficher l'image et les contours sur le buffer
        blit(image, page, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
        blit(contour_bitmap, page, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Afficher le contenu du buffer sur l'écran
        blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Petite pause pour limiter la vitesse de rafraîchissement
        rest(10);
    }

    // Libération de la mémoire
    destroy_bitmap(page);
    destroy_bitmap(image);
    destroy_bitmap(contour_bitmap);

}