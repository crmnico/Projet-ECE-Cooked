#include "Header.h"

#define OBJ_SIZE 20
#define OBJ_SPEED 2

BITMAP *page;
BITMAP *obj_bitmap;
int obj_x = 800 / 2;
int obj_y = 600 / 2;

void move_object() {
    // Déplacer l'objet automatiquement
    obj_x += OBJ_SPEED;

    // Réinitialiser la position de l'objet si elle dépasse les limites de l'écran
    if (obj_x >= SCREEN_W + OBJ_SIZE) {
        obj_x = -OBJ_SIZE;
        obj_y = rand() % SCREEN_H;
    }
}

int main_6() {
    // Initialisation Allegro
    allegro_init();
    install_keyboard();
    install_mouse();
    set_color_depth(desktop_color_depth());

    // Set graphics mode
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0) != 0) {
        allegro_message("Failed to set graphics mode!");
        allegro_exit();
        return 1;
    }

    int mouse_x, mouse_y;
    // Création du double buffer
    page = create_bitmap(SCREEN_W, SCREEN_H);

    // Charger une image pour représenter l'objet
    obj_bitmap = create_bitmap(OBJ_SIZE, OBJ_SIZE);
    clear_to_color(obj_bitmap, makecol(250, 10, 0));
    circlefill(obj_bitmap, OBJ_SIZE / 2, OBJ_SIZE / 2, OBJ_SIZE / 2, makecol(255, 255, 255));

    // Boucle principale
    while (!key[KEY_ESC]) {
        // Effacer le buffer
        clear_bitmap(page);

        // Déplacer l'objet
        move_object();

        // Dessiner l'objet à sa position actuelle
        draw_sprite(page, obj_bitmap, obj_x, obj_y);

        // Mettre à jour la position de la souris
        mouse_x = mouse_x;
        mouse_y = mouse_y;

        // Afficher la position de la souris
        textprintf_ex(page, font, 10, 10, makecol(255, 255, 255), -1, "Mouse X: %d, Mouse Y: %d", mouse_x, mouse_y);

        // Vérifier si le joueur a cliqué sur l'objet
        if (mouse_b & 1 && mouse_x >= obj_x && mouse_x <= obj_x + OBJ_SIZE && mouse_y >= obj_y && mouse_y <= obj_y + OBJ_SIZE) {
            // Le joueur a cliqué sur l'objet, réinitialiser sa position
            obj_x = -OBJ_SIZE;
            obj_y = rand() % SCREEN_H;
        }

        // Afficher le contenu du buffer sur l'écran
        blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Petite pause pour limiter la vitesse de rafraîchissement
        rest(10);
    }

    // Libération de la mémoire
    destroy_bitmap(page);
    destroy_bitmap(obj_bitmap);

}