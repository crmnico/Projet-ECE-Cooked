#include "Header.h"

BITMAP *page;
BITMAP *image1;
BITMAP *image2;
BITMAP *transition_image;

void transition_images(float param) {
    int x, y;

    // Parcourir chaque pixel des deux images
    for (y = 0; y < image1->h; y++) {
        for (x = 0; x < image1->w; x++) {
            // Récupérer la couleur des pixels dans les deux images
            int color1 = getpixel(image1, x, y);
            int color2 = getpixel(image2, x, y);

            // Interpoler les composantes de couleur
            int red = (1.0 - param) * getr(color1) + param * getr(color2);
            int green = (1.0 - param) * getg(color1) + param * getg(color2);
            int blue = (1.0 - param) * getb(color1) + param * getb(color2);

            // Dessiner le pixel correspondant sur l'image de transition
            putpixel(transition_image, x, y, makecol(red, green, blue));
        }
    }
}

int main_3() {
    // Initialisation Allegro
    allegro_init();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0))!=0)
    {
        allegro_message("pb mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    // Création du double buffer
    page = create_bitmap(SCREEN_W, SCREEN_H);

    // Chargez vos images depuis des fichiers
    image1 = load_bitmap("images/vague.bmp", NULL);
    image2 = load_bitmap("images/surf.bmp", NULL);

    // Vérification du chargement des images
    if (!image1 || !image2) {
        allegro_message("Impossible de charger les images !");
        return 1;
    }

    // Créer une bitmap pour stocker l'image de transition
    transition_image = create_bitmap(SCREEN_W, SCREEN_H);

    // Boucle principale
    float param = 0.0;
    while (param <= 1.0 && !key[KEY_ESC]) {
        // Effacer le buffer
        clear_bitmap(page);

        // Effectuer la transition entre les images
        transition_images(param);

        // Afficher l'image de transition sur l'écran
        blit(transition_image, page, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Afficher le contenu du buffer sur l'écran
        blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Augmenter le paramètre de transition
        param += 0.01;

        // Petite pause pour limiter la vitesse de rafraîchissement
        rest(10);
    }

    // Libération de la mémoire
    destroy_bitmap(page);
    destroy_bitmap(image1);
    destroy_bitmap(image2);
    destroy_bitmap(transition_image);

}