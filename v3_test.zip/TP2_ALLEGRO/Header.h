#ifndef TP2_ALLEGRO_HEADER_H
#define TP2_ALLEGRO_HEADER_H

#endif //TP2_ALLEGRO_HEADER_H

#include <allegro.h>
#include <math.h>

int main_1();
int main_2();
void modify_colors();
void transition_images(float param);
int main_3();
void detect_contours();
int main_4();
void move_object2(int dx, int dy);
void rotate_image(BITMAP *src, BITMAP *dest, double angle);
int main_5();
void move_object();
int main_6();