#include "Header.h"

#define OBJ1_SPEED    2

BITMAP *page;
BITMAP *image1;
BITMAP *image2;
BITMAP *image3;
int obj2_x = 800 / 2;
int obj2_y = 600 / 2;
int last_dx = 0; // Last movement direction on x-axis
int last_dy = 0; // Last movement direction on y-axis


void move_object2(int dx, int dy) {
    // Move object 2 according to the specified offset
    obj2_x += dx;
    obj2_y += dy;

    // Check screen boundaries for object 2
    if (obj2_x < 0)
        obj2_x = SCREEN_W - 1;
    else if (obj2_x >= SCREEN_W)
        obj2_x = 0;

    if (obj2_y < 0)
        obj2_y = SCREEN_H - 1;
    else if (obj2_y >= SCREEN_H)
        obj2_y = 0;

    // Update last movement direction
    if (dx != 0 || dy != 0) {
        last_dx = dx;
        last_dy = dy;
    }
}


void rotate_image(BITMAP *src, BITMAP *dest, double angle) {
    int cx = src->w / 2; // Center X of the source image
    int cy = src->h / 2; // Center Y of the source image
    rotate_sprite(dest, src, obj2_x, obj2_y, ftofix(angle));
}

int main_5() {
    // Initialize Allegro
    if (allegro_init() != 0) {
        allegro_message("Failed to initialize Allegro!");
        return 1;
    }

    // Install keyboard
    install_keyboard();

    // Set color depth
    set_color_depth(desktop_color_depth());

    // Set graphics mode
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0) != 0) {
        allegro_message("Failed to set graphics mode!");
        allegro_exit();
        return 1;
    }

    // Create double buffer
    page = create_bitmap(SCREEN_W, SCREEN_H);

    // Load images
    image1 = load_bitmap("images/parquet.bmp", NULL);
    image2 = load_bitmap("images/perso.bmp", NULL);
    image3 = load_bitmap("images/cuisiniere.bmp",NULL);

    // Check image loading
    if (!image1 || !image2 || !image3) {
        allegro_message("Failed to load images!");
        destroy_bitmap(page);
        allegro_exit();
        return 1;
    }

    // Main loop
    while (!key[KEY_ESC]) {
        // Clear buffer
        clear_bitmap(page);

        // Move object 1 automatically
        blit(image1, page, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
        blit(image3,page,0,0,200,200,800,600);
        // Move object 2 with arrow keys
        int dx = 0, dy = 0;
        if (key[KEY_UP]) dy = -1;
        if (key[KEY_DOWN]) dy = 1;
        if (key[KEY_LEFT]) dx = -1;
        if (key[KEY_RIGHT]) dx = 1;

        // Normalize diagonal movement
        if (dx != 0 && dy != 0) {
            dx = dx / abs(dx);
            dy = dy / abs(dy);
        }

        move_object2(dx, dy);

        // Rotate object 2 based on movement direction
        if (last_dx != 0 || last_dy != 0) {
            double angle = atan2(last_dx, -last_dy); // Calculate angle
            rotate_image(image2, page, angle * 41);
        }

        // Display buffer content on screen
        blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Small delay to limit refresh rate
        rest(8);
    }

    // Free memory
    destroy_bitmap(page);
    destroy_bitmap(image1);
    destroy_bitmap(image2);

    // Exit Allegro
    allegro_exit();
}