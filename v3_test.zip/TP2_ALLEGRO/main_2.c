#include "Header.h"




int main_2() {

    allegro_init();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0))!=0)
    {
        allegro_message("pb mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    // Création du double buffer
    BITMAP *page = create_bitmap(SCREEN_W, SCREEN_H);

    // Chargez votre image depuis un fichier
    BITMAP *image = load_bitmap("images/surf.bmp", NULL);

    // Vérification du chargement de l'image
    if (!image) {
        allegro_message("Impossible de charger l'image !");
        return 1;
    }

    // Créer les bitmaps pour stocker les composantes de couleur
    BITMAP *red_component = create_bitmap(image->w, image->h);
    BITMAP *green_component = create_bitmap(image->w, image->h);
    BITMAP *blue_component = create_bitmap(image->w, image->h);
    BITMAP *binary_image = create_bitmap(image->w, image->h);

    // Modifier les couleurs de l'image
    //modify_colors();

    int x, y;

    // Parcourir chaque pixel de l'image
    for (y = 0; y < image->h; y++) {
        for (x = 0; x < image->w; x++) {
            // Récupérer la couleur du pixel
            int color = getpixel(image, x, y);

            // Extraire les composantes rouge, vert et bleu
            int red = getr(color);
            int green = getg(color);
            int blue = getb(color);

            // Appliquer la modification des couleurs selon les spécifications
            // Pour l'exemple, nous allons binariser l'image en rouge, vert et bleu
            red = (red < 128) ? 0 : 255;
            green = (green < 128) ? 0 : 255;
            blue = (blue < 128) ? 0 : 255;

            // Dessiner le pixel sur les bitmaps correspondantes
            putpixel(red_component, x, y, makecol(red, 0, 0));
            putpixel(green_component, x, y, makecol(0, green, 0));
            putpixel(blue_component, x, y, makecol(0, 0, blue));

            // Version binarisée de l'image
            int binarized_color = makecol(red, green, blue);
            putpixel(binary_image, x, y, binarized_color);
        }
    }

    // Boucle principale
    while (!key[KEY_ESC]) {
        // Effacer le buffer
        clear_bitmap(page);

        // Afficher les composantes de couleur et l'image binarisée
        blit(red_component, page, 0, 0, 0, 0, SCREEN_W / 4, SCREEN_H / 2);
        blit(green_component, page, 0, 0, SCREEN_W / 4, 0, SCREEN_W / 4, SCREEN_H / 2);
        blit(blue_component, page, 0, 0, SCREEN_W / 2, 0, SCREEN_W / 4, SCREEN_H / 2);
        blit(binary_image, page, 0, 0, 3 * SCREEN_W / 4, 0, SCREEN_W / 4, SCREEN_H / 2);

        // Afficher le contenu du buffer sur l'écran
        blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Petite pause pour limiter la vitesse de rafraîchissement
        rest(10);
    }

    // Libération de la mémoire
    destroy_bitmap(page);
    destroy_bitmap(image);
    destroy_bitmap(red_component);
    destroy_bitmap(green_component);
    destroy_bitmap(blue_component);
    destroy_bitmap(binary_image);

}

