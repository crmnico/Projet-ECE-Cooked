#include "Header.h"

int main_1() {
    allegro_init();
    install_mouse();
    enable_hardware_cursor();
    install_keyboard();

    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, SCREEN_W, SCREEN_H, 0, 0) != 0) {
        allegro_message("Erreur chargement");
        return 1;
    }

    while (!key[KEY_ESC]) {

        clear_bitmap(screen);

        textprintf_ex(screen, font, 0, 0, makecol(255, 255, 255), -1, "SCREEN_W: %d", SCREEN_W);
        textprintf_ex(screen, font, 0, 10, makecol(255, 255, 255), -1, "SCREEN_H: %d", SCREEN_H);

        textprintf_ex(screen, font, 0, 20, makecol(255, 255, 255), -1, "Mouse X: %d", mouse_x);
        textprintf_ex(screen, font, 0, 30, makecol(255, 255, 255), -1, "Mouse Y: %d", mouse_y);

        rest(10);
        vsync();

    }

    allegro_exit();
    return 0;
}