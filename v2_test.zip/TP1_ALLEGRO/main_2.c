#include "Header.h"

int main_2() {
    allegro_init();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);

    while (!key[KEY_ESC]) {
        ellipse(screen, 320, 240, 50, 100, makecol(255, 0, 0));
    }
    allegro_exit();
    return 0;
}