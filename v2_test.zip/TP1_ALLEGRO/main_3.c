#include "Header.h"

int main_3() {
    allegro_init();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, SCREEN_W, SCREEN_H, 0, 0);

    int x = 0, y = SCREEN_H / 2;
    int dx = 5; // Déplacement horizontal

    while (!key[KEY_ESC]) {
        clear_to_color(screen, makecol(0, 0, 0)); // Efface l'écran

        rectfill(screen, x, y, x + 20, y + 20, makecol(255, 0, 0)); // Dessine un rectangle

        x += dx;
        if (x <= 0 || x >= SCREEN_W - 20)
            dx = -dx;

        rest(50);
    }

    allegro_exit();
    return 0;
}