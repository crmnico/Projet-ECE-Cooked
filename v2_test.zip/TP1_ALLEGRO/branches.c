#include "Header.h"

void branches(int x, int y, int largeur, int hauteur, int epaisseur) {
    if (epaisseur > 0) {
        for (int i = 0; i < epaisseur; i++) {
            line(screen, x + i, y, x + i + largeur, y - hauteur, makecol(255, 255, 255));
            line(screen, x + i, y, x + i - largeur, y - hauteur, makecol(255, 255, 255));
        }
        branches(x + largeur, y - hauteur, largeur / 2, hauteur / 2, epaisseur / 2);
        branches(x - largeur, y - hauteur, largeur / 2, hauteur / 2, epaisseur / 2);
    }
}