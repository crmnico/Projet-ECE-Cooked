#ifndef TP1_ALLEGRO_HEADER_H
#define TP1_ALLEGRO_HEADER_H

#endif //TP1_ALLEGRO_HEADER_H

#include <allegro.h>
#include <unistd.h>

#define SCREEN_W 640
#define SCREEN_H 480

int main_1();
int main_2();
int main_3();
void branches(int x, int y, int largeur, int hauteur, int epaisseur);
int main_4();