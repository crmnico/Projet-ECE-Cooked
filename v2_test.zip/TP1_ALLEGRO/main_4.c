#include "Header.h"

int main_4() {
    allegro_init();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0);

    while (!key[KEY_ESC]) {
        branches(400, 600, 192, 192, 64);
    }

    allegro_exit();
    return 0;
}