#include "Header.h"

void jeu(){
    clear_bitmap(page);

    debut_jeu = clock();
    initialisation_perso();
    initialisation_file(&file);
    //initialisation_niveau();

    ajout_commande(&file);

    while (!key[KEY_ESC]) {

        clear_bitmap(page);

        blit(map, page, 0, 0, 0, 60, TAILLE_ECRAN_L, TAILLE_ECRAN_H);

        ////TOUCHES////
        mouvement_perso1();
        mouvement_perso2();

        ////PERSONNAGE////
        update_position();
        update_direction();
        update_frame();
        dessine_perso();

        ////COMMANDE/////
        update_commande(&file);
        update_tempsCommands(&file);
        dessine_commande(&file);

        blit(page, screen, 0, 0, 0, 0, TAILLE_ECRAN_L, TAILLE_ECRAN_H);

        rest(50);
    }
}