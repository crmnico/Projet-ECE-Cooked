#include "Header.h"

// Initialise une file vide
void initialisation_file(File *file) {
    file->debut = NULL;
    file->fin = NULL;
}