#include "Header.h"

void chargement_menu(){
    calque_menu[0]= load_bitmap("Images/calque_menu_0.bmp",NULL);
    calque_menu[1]= load_bitmap("Images/calque_menu_1.bmp",NULL);
    calque_menu[2]= load_bitmap("Images/calque_menu_2.bmp",NULL);
    calque_menu[3]= load_bitmap("Images/calque_menu_3.bmp",NULL);
}