#include "Header.h"

void update_position() {
    // Move object 2 according to the specified offset
    perso1.pos_x += perso1.dx;
    perso1.pos_y += perso1.dy;

    // Check screen boundaries for object 2
    if (perso1.pos_x < 0) perso1.pos_x = TAILLE_ECRAN_L - 1;
    else if (perso1.pos_x >= TAILLE_ECRAN_L) perso1.pos_x = 0;

    if (perso1.pos_y < 0) perso1.pos_y = TAILLE_ECRAN_H - 1;
    else if (perso1.pos_y >= TAILLE_ECRAN_H) perso1.pos_y = 0;

    // Move object 2 according to the specified offset
    perso2.pos_x += perso2.dx;
    perso2.pos_y += perso2.dy;

    // Check screen boundaries for object 2
    if (perso2.pos_x < 0) perso2.pos_x = TAILLE_ECRAN_L - 1;
    else if (perso2.pos_x >= TAILLE_ECRAN_L) perso2.pos_x = 0;

    if (perso2.pos_y < 0) perso2.pos_y = TAILLE_ECRAN_H - 1;
    else if (perso2.pos_y >= TAILLE_ECRAN_H) perso2.pos_y = 0;


}