#include "Header.h"

int main_2()
{
    init_2();
    main_loop_2();
}