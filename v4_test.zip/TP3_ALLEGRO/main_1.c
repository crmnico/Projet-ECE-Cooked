#include "Header.h"

int main_1() {
    srand(time(NULL));
    init_1();

    // Initialiser les positions et les couleurs des bulles
    for (int i = 0; i < BUBBLE_COUNT; i++) {
        bulles[i].x = rand() % (800 - 2 * BUBBLE_RADIUS) + BUBBLE_RADIUS; // Position aléatoire
        bulles[i].y = rand() % (600 - 2 * BUBBLE_RADIUS) + BUBBLE_RADIUS;
        bulles[i].active = 1; // Initialiser les bulles comme actives
        bulles[i].color = makecol(rand() % 256, rand() % 256, rand() % 256); // Couleur aléatoire
    }

    while (!key[KEY_ESC]) {
        rafraichissement_1();

        clear_to_color(buffer, makecol(0, 0, 0)); // Effacer le buffer

        // Dessiner l'image de fond
        draw_sprite(buffer, background, 0, 0);

        // Dessiner les bulles actives
        for (int i = 0; i < BUBBLE_COUNT; i++) {
            if (bulles[i].active == 1) {
                circlefill(buffer, bulles[i].x, bulles[i].y, BUBBLE_RADIUS, bulles[i].color);
            }
        }

        // Dessiner le curseur à la position de la souris
        draw_sprite(buffer, cursor, mouse_x, mouse_y);

        // Actualiser l'écran
        blit(buffer, screen, 0, 0, 0, 0, 800, 600);

        rest(20);
    }

    // Libérer la mémoire
    destroy_bitmap(background);
    destroy_bitmap(buffer);
    destroy_bitmap(cursor);
}