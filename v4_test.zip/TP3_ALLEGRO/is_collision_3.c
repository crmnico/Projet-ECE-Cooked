#include "Header.h"

int is_collision_3()
{
    int mouse_x = mouse_x;
    int mouse_y = mouse_y;

    // Récupérer la couleur du pixel à la position de la souris sur l'image de l'étoile de la mort
    int pixel_color = getpixel(etoile1_3, mouse_x, mouse_y);

    // Vérifier si la couleur du pixel correspond à la couleur de l'étoile de la mort
    // Vous devrez remplacer la valeur de la couleur de l'étoile de la mort par la couleur réelle de votre image
    if (pixel_color == makecol(255, 0, 255)) {
        return 1; // L'étoile de la mort est touchée
    } else {
        return 0; // Aucune collision détectée
    }
}