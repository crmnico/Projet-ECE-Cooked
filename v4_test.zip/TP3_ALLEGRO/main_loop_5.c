#include "Header.h"

void main_loop_5()
{
    int cat_x,cat_y, cat_speed;
    int flipped = 0; // Indique si le chat est retourné

    while (!key[KEY_ESC]) {
        clear_to_color(buffer_5, makecol(0, 0, 0)); // Effacer le buffer

        // Dessiner l'image de fond
        draw_sprite(buffer_5, background_5, 0, 0);

        // Gérer la chute du chat
        cat_speed += 1; // Accélération de la chute
        cat_x += 2; // Déplacement horizontal du chat
        if (cat_x > SCREEN_W) { // Si le chat sort de l'écran, réinitialiser sa position
            cat_x = -CAT_WIDTH;
            cat_speed = 0;
            flipped = 0;
        }
        if (cat_y < GROUND_Y) // Si le chat n'a pas touché le sol, continuer la chute
            cat_y += cat_speed;
        else { // Si le chat touche le sol, le faire rebondir et le retourner
            cat_speed = -cat_speed / 2; // Rebondir en inversant la vitesse
            cat_y = GROUND_Y; // Le maintenir sur le sol
            flipped = !flipped; // Retourner le chat
        }

        // Dessiner le chat sur le buffer
        draw_cat_5(cat_x, cat_y, flipped);

        // Afficher le buffer sur l'écran
        blit(buffer_5, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        rest(20); // Temporisation
    }
}