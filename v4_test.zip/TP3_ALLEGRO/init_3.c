#include "Header.h"

void init_3()
{
    allegro_init();
    install_keyboard();
    install_mouse();
    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);

    buffer_3 = create_bitmap(SCREEN_W, SCREEN_H);
    background_3 = load_bitmap("Images/parquet.bmp", NULL); // Charger l'image de fond
    etoile1_3 = load_bitmap("Images/etoile1.bmp", NULL); // Charger l'image de l'étoile de la mort en bon état
    etoile2_3 = load_bitmap("Images/etoile2.bmp", NULL); // Charger l'image de l'étoile de la mort totalement ravagée
}