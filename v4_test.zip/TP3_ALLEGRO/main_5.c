#include "Header.h"

int main_5()
{
    init_5();
    main_loop_5();
}