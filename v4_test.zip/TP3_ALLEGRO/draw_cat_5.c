#include "Header.h"

void draw_cat_5(int x, int y, int flipped)
{
    // Dessiner l'image du chat sur le buffer
    if (flipped)
        draw_sprite_h_flip(buffer_5, cat_5, x, y);
    else
        draw_sprite(buffer_5, cat_5, x, y);
}