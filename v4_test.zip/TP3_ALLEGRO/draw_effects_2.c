#include "Header.h"

void draw_effects_2()
{
    // Dessiner des effets spéciaux sur le buffer (à adapter selon les besoins)
    // Exemple : dessiner un rectangle rouge
    rectfill(buffer_2, 100, 100, 200, 200, makecol(255, 0, 0));
}