#include "Header.h"

void main_loop_3()
{
    int etoile_x = SCREEN_W / 2; // Position initiale de l'étoile de la mort
    int etoile_y = SCREEN_H / 2;
    int etoile_speed_x = 2; // Vitesse de déplacement de l'étoile de la mort
    int etoile_speed_y = 2;

    while (!key[KEY_ESC]) {
        clear_to_color(buffer_3, makecol(0, 0, 0)); // Effacer le buffer

        // Dessiner l'image de fond
        draw_sprite(buffer_3, background_3, 0, 0);

        // Dessiner des effets spéciaux
        draw_effects_3(etoile_x,etoile_y);

        // Déplacer l'étoile de la mort
        etoile_x += etoile_speed_x;
        etoile_y += etoile_speed_y;

        // Si l'étoile atteint les bords de l'écran, changer de direction
        if (etoile_x <= 0 || etoile_x >= SCREEN_W)
            etoile_speed_x *= -1;
        if (etoile_y <= 0 || etoile_y >= SCREEN_H)
            etoile_speed_y *= -1;

        // Afficher l'étoile de la mort sur le buffer (choisir l'image en fonction de l'état de destruction)
        if (is_collision_3()) { // Si l'étoile est touchée, afficher l'image ravagée
            draw_sprite(buffer_3, etoile2_3, etoile_x, etoile_y);
        } else { // Sinon, afficher l'image en bon état
            draw_sprite(buffer_3, etoile1_3, etoile_x, etoile_y);
        }

        // Afficher le buffer sur l'écran
        blit(buffer_3, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        rest(20); // Temporisation
    }
}