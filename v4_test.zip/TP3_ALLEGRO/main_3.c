#include "Header.h"

int main_3()
{
    init_3();
    main_loop_3();
}