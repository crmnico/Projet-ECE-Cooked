#include "Header.h"

int main_4()
{
    init_4();
    main_loop_4();
}