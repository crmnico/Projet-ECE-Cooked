#include "Header.h"

void init_4()
{
    allegro_init();
    install_keyboard();
    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);

    buffer_4 = create_bitmap(SCREEN_W, SCREEN_H);
    background_4 = load_bitmap("Images/parquet.bmp", NULL); // Charger l'image de fond

    // Charger les images de l'animation du bonhomme
    bonhomme_4[0] = load_bitmap("Image/bonhomme1.bmp", NULL);
    bonhomme_4[1] = load_bitmap("Image/bonhomme2.bmp", NULL);
    bonhomme_4[2] = load_bitmap("Image/bonhomme3.bmp", NULL);
    bonhomme_4[3] = load_bitmap("Image/bonhome4.bmp", NULL);
}