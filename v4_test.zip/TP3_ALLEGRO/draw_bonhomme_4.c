#include "Header.h"

void draw_bonhomme_4(int img_courante,int x,int y)
{
    // Dessiner l'image courante du bonhomme sur le buffer
    draw_sprite(buffer_4, bonhomme_4[img_courante], x, y);
}