#include "Header.h"

void main_loop_4()
{
    int bonhomme_x = SCREEN_W / 2; // Position du bonhomme
    int bonhomme_y = SCREEN_H / 2;
    int bonhomme_speed = 5; // Vitesse de déplacement du bonhomme
    int img_courante = 0; // Indice de l'image courante de l'animation
    int cpt_img = 0; // Compteur pour gérer la vitesse de l'animation

    while (!key[KEY_ESC]) {
        clear_to_color(buffer_4, makecol(0, 0, 0)); // Effacer le buffer

        // Dessiner l'image de fond
        draw_sprite(buffer_4, background_4, 0, 0);

        // Déplacer le bonhomme en fonction des touches du clavier
        if (key[KEY_RIGHT]) bonhomme_x += bonhomme_speed;
        if (key[KEY_LEFT]) bonhomme_x -= bonhomme_speed;
        if (key[KEY_DOWN]) bonhomme_y += bonhomme_speed;
        if (key[KEY_UP]) bonhomme_y -= bonhomme_speed;

        // Gérer l'animation du bonhomme
        cpt_img++;
        if (cpt_img >= 10) { // Changer d'image toutes les 10 itérations
            img_courante = (img_courante + 1) % 4; // Passer à l'image suivante
            cpt_img = 0; // Réinitialiser le compteur
        }

        // Dessiner le bonhomme sur le buffer
        draw_bonhomme_4(img_courante,bonhomme_x,bonhomme_y);

        // Afficher le buffer sur l'écran
        blit(buffer_4, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        rest(20); // Temporisation
    }
}