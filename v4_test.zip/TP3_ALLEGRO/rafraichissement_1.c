#include "Header.h"

void rafraichissement_1()
{
    int x = mouse_x;
    int y = mouse_y;

    // Vérifier si une bulle est cliquée
    if (mouse_b & 1) { // Si le bouton gauche de la souris est enfoncé
        for (int i = 0; i < BUBBLE_COUNT; i++) {
            if (bulles[i].active) {
                int dist_x = x - bulles[i].x;
                int dist_y = y - bulles[i].y;
                int distance = sqrt(dist_x * dist_x + dist_y * dist_y);
                if (distance <= BUBBLE_RADIUS) {
                    bulles[i].active = 0; // Désactiver la bulle si elle est cliquée
                }
            }
        }
    }

    // Mettre à jour les positions des bulles
    for (int i = 0; i < BUBBLE_COUNT; i++) {
        if (bulles[i].active) {
            // Déplacer la bulle horizontalement
            bulles[i].x += BUBBLE_SPEED;
            bulles[i].y += BUBBLE_SPEED;
            // Vérifier si la bulle est sortie de l'écran
            if(bulles[i].x > 800){
                bulles[i].x= 0;
                bulles[i].y= rand() % SCREEN_H;
            }
            if(bulles[i].y > 600){
                bulles[i].x= rand() % SCREEN_W;
                bulles[i].y= 0;
            }
        }
    }

}
