#include "Header.h"

void init_1()
{
    allegro_init();
    install_mouse();
    install_keyboard();
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0)!=0)
    {
        allegro_message("prb gfx mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }

    buffer = create_bitmap(800, 600);
    background = load_bitmap("images/fond_decran.bmp", NULL); // Charger l'image de fond
    cursor = load_bitmap("images/curseur.bmp", NULL); // Charger l'image du curseur

}