#include "Header.h"

void main_loop_2()
{
    while (!key[KEY_ESC]) {
        clear_to_color(buffer_2, makecol(0, 0, 0)); // Effacer le buffer

        // Dessiner l'image de fond
        draw_sprite(buffer_2, background_2,0, 0);

        // Dessiner des effets spéciaux
        draw_effects_2();

        // Afficher le buffer sur l'écran
        blit(buffer_2, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        rest(20); // Temporisation
    }
}