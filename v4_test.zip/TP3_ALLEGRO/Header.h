#ifndef TP3_ALLEGRO_HEADER_H
#define TP3_ALLEGRO_HEADER_H

#endif //TP3_ALLEGRO_HEADER_H

#include <stdio.h>
#include <allegro.h>
#include <math.h>

#define CAT_WIDTH 64
#define CAT_HEIGHT 64
#define GROUND_Y (SCREEN_H - CAT_HEIGHT)
#define BUBBLE_COUNT 20
#define BUBBLE_RADIUS 20
#define BUBBLE_SPEED 1

BITMAP *buffer;
BITMAP *background;
BITMAP *cursor; // Image du curseur

typedef struct {
    int x;
    int y;
    int active;
    int color;
} Bulles;

Bulles bulles[BUBBLE_COUNT];
void init_1();
void rafraichissement_1();
int main_1();

BITMAP *buffer_2;
BITMAP *background_2;

void init_2();
void draw_effects_2();
void main_loop_2();
int main_2();

BITMAP *buffer_3;
BITMAP *background_3;
BITMAP *etoile1_3; // Image de l'étoile de la mort en bon état
BITMAP *etoile2_3; // Image de l'étoile de la mort totalement ravagée

void init_3();
void draw_effects_3(int etoile_x,int etoile_y);
int is_collision_3();
void main_loop_3();
int main_3();

BITMAP *buffer_4;
BITMAP *background_4;
BITMAP *bonhomme_4[4]; // Tableau pour stocker les images de l'animation du bonhomme

void init_4();
void draw_bonhomme_4(int img_courante,int x,int y);
void main_loop_4();
int main_4();

BITMAP *buffer_5;
BITMAP *background_5;
BITMAP *cat_5; // Image du chat

void init_5();
void draw_cat_5(int x, int y, int flipped);
void main_loop_5();
int main_5();
