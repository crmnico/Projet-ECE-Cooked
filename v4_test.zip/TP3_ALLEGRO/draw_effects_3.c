#include "Header.h"

void draw_effects_3(int etoile_x,int etoile_y)
{
    // Dessiner des effets spéciaux sur le buffer (à adapter selon les besoins)
    // Exemple : dessiner un cercle rouge autour de l'étoile de la mort
    circlefill(buffer_3, etoile_x, etoile_y, 30, makecol(255, 0, 0));
}