#include "Header.h"

void init_5()
{
    allegro_init();
    install_keyboard();
    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);

    buffer_5 = create_bitmap(SCREEN_W, SCREEN_H);
    background_5 = load_bitmap("Image/parquet.bmp", NULL); // Charger l'image de fond
    cat_5 = load_bitmap("Image/cat.bmp", NULL); // Charger l'image du chat
}